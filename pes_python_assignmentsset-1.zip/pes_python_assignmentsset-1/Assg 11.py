#! /usr/bin/python
#Read 2 numbers to variable a and b and perform all bitwise operations on that numbers
a=60
b=13
res = a & b
print "The AND of 60 and 13 is:", res
res = a | b
print "The OR of 60 and 13 is:", res
res = a ^ b
print "The XOR of 60 and 13 is:", res
res = ~ a
print "The Complement of 60 is:", res
res = a >> 2
print "The Right Shift of 60 is:", res
res = a << 2
print "The Left Shift of 60 is:", res


