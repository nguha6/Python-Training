#! /usr/bin/python
#Using loop structures print numbers from 1 to 100.  and using the same loop print numbers from 100 to 1 (reverse printing)
# a) By using For loop 

list=[]
for n in range(1,101):
    list.append(n)
print "List is:", list
list.reverse()
print "Reverse List is:", list

#b) By using while loop

x=[]
i=1
while i<=100:
     x.append(i)
     i+=1
print "List is:", x
x.reverse()
print "Reverse List is:", x

#c) Let mystring ="Hello world" print each character of mystring in to separate line using appropriate loop structure

mystring ="Hello world"
i=0
while i < len(mystring):
    print mystring[i]
    i += 1

