#! /usr/bin/python
#Write a program to receive 5 command line arguments and print each argument separately. Example: >> python test.py arg1 arg2 arg3 arg4 arg5
# a) From the above statement your program should receive arguments and print them each of them

import sys

print "You entered arguments:", sys.argv
