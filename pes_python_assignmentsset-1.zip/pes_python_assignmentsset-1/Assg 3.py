#! /usr/bin/python
#Write a program to find given number is odd or Even
a=6
if(a%2==0):
    print "This Number is Even"
else:
    print("This Number is Odd")
