#! /usr/bin/python
#Write a program to read string and print each character separately.
   
x="Mountain"
print "String is:", x
c = list(x)
print "Characters:", c

#Slice the string using slice operator [:]
#Slice the portion the strings to create a sub strings.

print "Sliced Characters:", c[0:2]
e=c[0:4]
f=c[4:]
print "Substring", e,f


#Repeat the string 100 times using repeat operator *
d = x*100
print "Repeated String:", d

#Read string 2 and concatenate with other string using + operator.
y="Long"
print "Other String is:", y
d = x+y
print "Combined String:", d

