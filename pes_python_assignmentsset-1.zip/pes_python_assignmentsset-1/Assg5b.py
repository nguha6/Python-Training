#! /usr/bin/python
#b) Find the biggest of three numbers, where three numbers are passed as command line arguments

import sys
a = int(sys.argv[1])
b = int(sys.argv[2])
c = int(sys.argv[3])
if (a > b) and (a > c):
    biggest = a
elif (b > a) and (b > c):
    biggest = b
else:
    biggest = c
print "You entered:", (a,b,c)
print "The biggest number of them:", biggest
