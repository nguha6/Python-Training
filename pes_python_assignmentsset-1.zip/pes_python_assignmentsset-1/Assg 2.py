#! /usr/bin/python
#Write a program to find the biggest of 3 numbers (Use If Condition)
a=10
b=5
c=25
if (a > b) and (a > c):
    biggest = a
elif (b > a) and (b > c):
    biggest = b
else:
    biggest = c
print "The biggest number between %d ,%d, %d is %d" % (a,b,c,biggest)
