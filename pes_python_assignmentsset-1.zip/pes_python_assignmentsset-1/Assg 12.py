#! /usr/bin/python
#Read 10 numbers from user and find the average of all.

total_sum = 0
x=[]
for n in range(10):
    numbers = input("Enter number: ")
    x.append(numbers)
    total_sum += numbers
avg = total_sum/10
print "Average of 10 numbers is :", avg

#a) Use comparison operator to check how many numbers are less than average and print them

count = 0
for n in range(10):
    if x[n] < avg:
        count+=1
        print "Number less than average:", x[n]
print "Total number of numbers below average:", count

#b) Check how many numbers are more than average.

count = 0

for n in range(10):
    if x[n] > avg:
        count+=1
        print "Number less than average:", x[n]
print "Total number of numbers above average:", count

#c) How many are equal to average.

count = 0
for n in range(10):
    if x[n] == avg:
        count+=1
        print "Number less than average:", x[n]
print "Total number of numbers equal average:", count
