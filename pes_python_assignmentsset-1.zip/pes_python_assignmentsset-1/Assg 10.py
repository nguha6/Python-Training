#! /usr/bin/python
#Using assignment operators, perform following operations Addition, Substation, Multiplication, Division, Modulus, Exponent and Floor division operations

a=67
b=32
c=a+b
print "Result 1 for 2 numbers: ", a,b
c+=a
print "Result 2 - Assignment Addition is ", c
c-=a
print "Result 3 - Assignment Subtraction ", c
c*=a
print "Result 4 - Assignment Multiplication ", c
c/=a
print "Result 5 - Assignment Division ", c
c%=a
print "Result 6 - Assignment Modulus ", c
c**=a
print "Result 7 - Assignment Exponent ", c
c//=a
print "Assignment Floor Division ", c
