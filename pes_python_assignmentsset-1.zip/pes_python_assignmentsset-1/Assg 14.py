#! /usr/bin/python
#Write a program to create two list A & B such that List A contains Employee Id, List B contain Employee name (minimum 10 entries in each list)
#& perform following operation a) Print all names on to screen
EmpID = [1,2,3,4,5,6,7,8,9,10]
EmpName =['Ann','John','Mary','Tim','Simy','Rita','Sita','Harry','Jenny','Karen']
print "Emp Name is ", EmpName

#b) Read the index from the  user and print the corresponding name from both list

x=input("Select position of name for whom you want Emp ID: ")
print "Emp Details for position", x
print "Emp ID :", EmpID[x-1]
print "Emp Name:", EmpName[x-1]

#c) Print the names from 4th position to 9th position


print "Emp Name from 4th th 9th position", EmpName[3:9]

#d) Print all names from 3rd position till end of the list
print "Emp Name from 3rd position", EmpName[2:]

#e) Repeat list elements by specified number of times (N- times, where N is entered by user)
x=input("Enter number of times list to be repeated: ")
print "Repeating list"
n=1
while n<=x :
    print EmpID
    print EmpName
    n+=1
print "Done"

#f)  Concatenate two lists and print the output
list1=EmpID+EmpName
print "Concatenated List", list1

#g) Print element of list A and B side by side.(i.e. List-A First element, List-B First element )
print "Concatenated Element"
n=0
while n<=9:
    print EmpID[n], EmpName[n]
    n+=1
print "Done"
