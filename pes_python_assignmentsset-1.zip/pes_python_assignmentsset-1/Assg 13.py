#! /usr/bin/python
#Write a program to find the biggest of 4 numbers/ Read 4 numbers from user using Input statement


num1 = 2
num2 = 57
num3 = 85
num4 = 32
 
if (num1 > num2) and (num1 > num3) and (num1 > num4) :
   largest = num1
elif (num2 > num1) and (num2 > num3) and (num2 > num4):
   largest = num2
elif (num3 > num1) and (num3 > num2) and (num3 > num4):
   largest = num3
else:
   largest = num4
 
print("The largest of 4 numbers is",largest)

#Extend the above program to find the biggest of 5 numbers

num1 = 2
num2 = 57
num3 = 85
num4 = 32
num5 = 197
 
if (num1 > num2) and (num1 > num3) and (num1 > num4) and (num1 > num5) :
   largest = num1
elif (num2 > num1) and (num2 > num3) and (num2 > num4) and (num2 > num5):
   largest = num2
elif (num3 > num1) and (num3 > num2) and (num3 > num4) and (num3 > num5):
   largest = num3
elif (num4 > num1) and (num4 > num2) and (num4 > num3) and (num4 > num5):
   largest = num4
else:
   largest = num5
 
print("The largest number of 5 nubers is",largest)
