#! /usr/bin/python
# Using loop structures print even numbers between 1 to 100.

list=[]
for number in range(1, 101):
    if(number % 2 == 0):
        list.append(number)
print "Even number list is:", list

# By using For loop, use continue/ break/ pass statement to skip odd numbers.
list=[]
for x in range(1,101):
    if(x % 2 == 1):
        continue
    list.append(x)
print "List is:", list

# i) Break the loop if the value is 50
list=[]
for x in range(1,101):
    if(x==50):
        break
    if(x % 2 == 1):
        continue
    list.append(x)
print "List is:", list

# ii) Use continue for the values 10,20,30,40,50

list=[]
for x in range(1,101):
    if(x==50):
        break
    if(x % 2 == 1):
        continue
    if x in (10,20,30,40,50):
        continue
    list.append(x)
print "List is:", list

#b) By using while loop, use continue/ break/ pass statement to skip odd numbers.

x=[]
i=1
while i<=100:
    i+=1
    if(i % 2 == 1):
        continue
    x.append(i)
print "List is:", x

#i) Break the loop if the value is 90

x=[]
i=1
while i<=100:
    i+=1
    if(i==90):
        break
    if(i % 2 == 1):
        continue
    x.append(i)
print "List is:", x



#ii) Use continue for the values 60,70,80,90

x=[]
i=1
while i<=100:
    i+=1
    if(i==90):
        break
    if(i % 2 == 1):
        continue
    if i in (60,70,80,90):
        continue
    x.append(i)
print "List is:", x
