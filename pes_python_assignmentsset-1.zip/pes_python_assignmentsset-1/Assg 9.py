#! /usr/bin/python
#Write program to Add, Subtract, Multiply, Divide 2 Complex numbers
a=2
b=4
c=5
d=6
x = complex (a,b)
y = complex (c,d)
print "Complex Numbers are:", x,y
print "Addition:", x + y
print "Subtraction:",x - y
print "Multiplication:",x * y
print "Division:",x / y
