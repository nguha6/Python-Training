#! /usr/bin/python
#Create a tuple with at least 10 elements having integer values in it/ Print all elements

tupleValue=[10,20,30,40,50,60,70,80,90,100]
print "The given values of the list is" , tupleValue

#Create a tuple with at least 10 elements having integer values in it/ Perform slicing operations

tupleValue=[10,20,30,40,50,60,70,80,90,100]
print "The range of values from 0 - 4 is", tupleValue[0:5]
print "The first element of the list item is", tupleValue[0]
print "The fifth element of the list item is", tupleValue[5]
print "The range of values till 5th element is", tupleValue[:5]
print "The range of values after 1st element is", tupleValue[1:]
print "The range of values is", tupleValue[:]

#Create a tuple with at least 10 elements having integer values in it/ Perform repetition with * operator

tupleValue=[10,20,30,40,50,60,70,80,90,100]
c = tupleValue * 4
print "The repeated range", c

#Create a tuple with at least 10 elements having integer values in it/ Perform concatenation with other list

tupleValue=[10,20,30,40,50,60,70,80,90,100]
tupleValue1=[11,12,13,14]
c = tupleValue + tupleValue1
print "The complete range is", c

