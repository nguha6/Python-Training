#! /usr/bin/python
#Write program to find the biggest and Smallest of N numbers./ PS: Use the functions to find biggest and smallest numbers. 

lst = []
num = int(input('How many numbers: '))
for n in range(num):
    numbers = int(input('Enter number '))
    lst.append(numbers)
print "Maximum element in the list is :", max(lst)
print "Minimum element in the list is :", min(lst)
