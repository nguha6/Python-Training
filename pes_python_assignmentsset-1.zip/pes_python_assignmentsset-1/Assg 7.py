#! /usr/bin/python
#Create a list with at least 10 elements having integer values in it;Print all elements

listValue=[10,20,30,40,50,60,70,80,90,100]
print "The given values of the list is:" , listValue

#Perform slicing operations

print "The range of values from 0 - 4 is:", listValue[0:5]
print "The first element of the list item is:", listValue[0]
print "The fifth element of the list item is:", listValue[5]
print "The range of values till 5th element is:", listValue[:5]
print "The range of values after 1st element is:", listValue[1:]
print "The range of values is", listValue[:]

#Perform repetition with * operator

c = listValue * 4
print "The repeated range:", c

#Perform concatenation with other list.
listValue1=[11,12,13,14]
print "Second list:", listValue1
c = listValue + listValue1
print "The combined list is:", c
