#! /usr/bin/python
#Write program to perform following:i) Check whether given number is prime or not.
number=11
if number > 1:
    for i in range(2, number):
        if (number % i) == 0:
            print(number, "is not a prime number")
            break
    else:
        print(number, "is a prime number")
else:
    print(number, "is not a prime number")

#ii) Generate all the prime numbers between 1 to N where N is given number.
N=21
for a in range(2,N+1):
    k=0
    for i in range(2,a//2+1):
        if(a%i==0):
            k=k+1
    if(k<=0):
        print(a)
