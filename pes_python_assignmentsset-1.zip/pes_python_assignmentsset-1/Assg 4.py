#! /usr/bin/python
#Write a program to find the number is Prime or not
a=11
if a > 1: 
   for i in range(2, a//2):
       if (a % i) == 0: 
           print "%d is not a prime number" % (a) 
           break
   else: 
       print "%d is a prime number" % (a)
  
else: 
   print "%d is not a prime number" % (a)


