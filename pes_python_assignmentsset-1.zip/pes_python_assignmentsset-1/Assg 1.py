#! /usr/bin/python
#Write a program to Add, Subtract, Multiply, and Divide 2 numbers
a=10.0
b=5
print "The given numbers are %d and %d" % (a,b)
res = a + b
print "The Sum is %d " % res
res = a - b
print "The Difference is %d" % res
res = a * b
print "The Product is %d" % res
res = a / b
print "The Division is %f" % res
