#! /usr/bin/python
#Create a list of 5 names and check given name exist in the List.

#a) Use membership operator (IN) to check the presence of an element.
NameList =['Ann','John','Mary','Tim','Simy']
print "Name List is: ", NameList
x="John"
y="Jack"
if (x in NameList):
    print "Name in List:", x
else:
    print "Name not in List", x
if (y in NameList):
    print "Name in List:", x
else:
    print "Name not in List", y
#b) Perform above task without using membership operator.

if NameList.count('John') > 0:
    print "Yes, John found in List"
else:
    print "John not in list"
if NameList.count('Jack') > 0:
    print "Yes, Jack found in List"
else:
    print "Jack not in list"
    
#c) Print the elements of the list in reverse direction.
NameList.reverse()
print "Reverse Name List is:", NameList



